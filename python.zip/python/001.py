s="10";

d=5.3;

i=1;

c='Tekst';

print(str(i)+s)

print ("%s %f %s" % (s, d, c))